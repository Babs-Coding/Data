package uk.ac.le.cs.mobwebapp;

import org.apache.xerces.parsers.DOMParser;
import org.apache.xerces.parsers.SAXParser;
import org.w3c.dom.Document;
import org.w3c.dom.Node;


public class WebAppInterfaceParser {
	
	public static void main(String[] args)
    {
		
	//DOM	
	  try{
	  		DOMParser parser = new DOMParser();
	  		parser.parse("WebAppInterface.xml");
	  		Document doc = parser.getDocument();
	  		traverse_tree(doc);
	       }
	       catch(Exception e){
	          e.printStackTrace(System.err);
	       }
	  

    }
	
	  
	public static void traverse_tree(Node node){
		//Task 3	
	}
	
	// Or use SAX as you wish
	  /*
	     try{
			 
			WebServiceSAX SAXHandler = new WebServiceSAX();
	 		SAXParser parser = new SAXParser();
	 		parser.setContentHandler(SAXHandler);
	 		parser.setErrorHandler(SAXHandler);
	 		parser.parse("WebService.xml");
	 		//...Task 3....
		    }
			catch(Exception e){e.printStackTrace(System.err);
			}
	   */


}
